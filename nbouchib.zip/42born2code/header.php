<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes() ?>>
<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="content-type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<title><?php wp_title( '-', true, 'right' ); echo wp_specialchars( get_bloginfo('name'), 1 ) ?></title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style.css" type="text/css" media="screen" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.1/jquery.min.js"></script>

	<!--[if lte IE 6]><script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/supersleight-min.js"></script><![endif]-->
<?php wp_enqueue_script(get_bloginfo('template_directory').'/js/jquery.js'); ?>
<?php wp_enqueue_script('superfish', get_bloginfo('template_directory').'/js/superfish.js', array('jquery'), '1.7'); ?>
<?php wp_enqueue_script(get_bloginfo('template_directory').'/js/nav.js'); ?>
<?php if (trim(get_option('ft_header_code')) <> "") { echo stripslashes(get_option('ft_header_code')); } ?>
<?php if (is_singular()) wp_enqueue_script('comment-reply'); ?>

<?php wp_head(); ?> <!-- #NE PAS SUPPRIMER cf. codex wp_head() -->
</head>
<script type="text/javascript">
$(document).ready(function() {
//Lorsque vous cliquez sur un lien de la classe poplight et que le href commence par #
$('a.poplight[href^=#]').click(function() {
	var popID = $(this).attr('rel'); //Trouver la pop-up correspondante
	var popURL = $(this).attr('href'); //Retrouver la largeur dans le href

	//Récupérer les variables depuis le lien
	var query= popURL.split('?');
	var dim= query[1].split('&amp;');
	var popWidth = dim[0].split('=')[1]; //La première valeur du lien

	//Faire apparaitre la pop-up et ajouter le bouton de fermeture
	$('#' + popID).fadeIn().css({
		'width': Number(popWidth)
	})

	//Récupération du margin, qui permettra de centrer la fenêtre - on ajuste de 80px en conformité avec le CSS
	var popMargTop = ($('#' + popID).height() + 80) / 2;
	var popMargLeft = ($('#' + popID).width() + 80) / 2;

	//On affecte le margin
	$('#' + popID).css({
		'margin-top' : -popMargTop,
		'margin-left' : -popMargLeft
	});

	//Effet fade-in du fond opaque
	$('body').append('<div id="fade"></div>'); //Ajout du fond opaque noir
	//Apparition du fond - .css({'filter' : 'alpha(opacity=80)'}) pour corriger les bogues de IE
	$('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn();

	return false;
});

//Fermeture de la pop-up et du fond
$('a.close, #fade').live('click', function() { //Au clic sur le bouton ou sur le calque...
	$('#fade , .popup_block').fadeOut(function() {
		$('#fade, a.close').remove();  //...ils disparaissent ensemble
	});
	return false;
});
});

</script>
<body <?php body_class() ?>>
<div id="header">
<?php $input = array("Paris", "SanFrancisco", "Seoul");
$rand_keys = array_rand($input, 1);
$input[$rand_keys] . "\n";?>
<div id="video"><video loop="loop" preload="auto" autoplay="true" width="2560px">
        <source src="//a0.muscache.com/airbnb/static/<?php echo "$input[$rand_keys]"?>-P1-1.mp4" type="video/mp4">
        <source src="//a0.muscache.com/airbnb/static/<?php echo "$input[$rand_keys]"?>-P1-0.webm" type="video/webm">
      </video>
     </div>
<div id="registration"><?php
if (is_user_logged_in())
	echo "<p class='button'><a href=".wp_logout_url(home_url()).">Se déconnecter</a></p>";
else
{
	echo "<a href='#?w=500' rel='popup_signin' class='poplight'>S'enregistrer</a>";
	echo "<div id='popup_signin' class='popup_block'>";?>
	<form name='loginform' id='loginform' method='POST' action='http://wp.local.42.fr:8080/wp-login.php?action=register'>
	<p class='login-username'>
	<label for='user_login'>Identifiant</label>
	<input type='text' name='user_login' id='user_login' class='input' value size='20'/>
	</p>
	<p class='login-email'>
	<label for='user_mail'>Email</label>
	<input type='text' name='user_email' id='user_email' class='input' value size='20'/>
	</p>
	<p class='login-password'>
	<label for='user_pass'>Mot de passe</label>
	<input type='password' name='user_pass' id='user_pass' class='input' value size='20'/>
	</p>
	<p class='login-submit'>
	<input type="submit" name="wp-submit" id="wp_submit" class="button-primary" value="S'inscrire"/>
	<input type="hidden" name="redirect_to" value="http://wp.local.42.fr:8080"/>
	</p>
	</form>
	<?php
	echo "</div>";
	echo "<a href='#?w=500' rel='popup_login' class='poplight'>Se connecter</a>";
	echo "<div id='popup_login' class='popup_block'>";
		wp_login_form();
	echo "</div>";
	echo "<p class='announce'><a href='#'>Publiez votre annonce</a></p>";
}
?>
</div>
<div id="title" style="position: absolute; top: 0px">BIENVENUE À LA MAISON</div>
<div id="subtitle" style="position: absolute; top: 0px">Louez des logements uniques auprès d'hôtes locaux dans 190+ pays.</div>
<div id="top">
	<div class="pads clearfix"><?php wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'sort_column' => 'menu_order', 'container_class' => 'nav' ) ); ?>
	</div>
</div>
<a href="<?php echo get_option('home'); ?>">
			<img id="site-logo" src="<?php bloginfo('template_directory'); ?>/images/logo.png" alt="<?php bloginfo('name'); ?>"/>
		</a>
		<div id="deco" position="absolute" top="0px"></div>
	<div class="pads clearfix">
		<div id="blocsearch" style="position: absolute; top: 0px;"> <?php include('searchform.php'); ?></div>
		<div class="nav-wrap">
			<div id="nav">
			<?php wp_nav_menu( array( 'menu' => 'Menu' ) ); ?>
			</div>
		</div>
	</div>
</div>
<!--  #header -->

<div id="container">
	<div class="pads clearfix">