<?php get_header() ?>

<div id="content_index">
<div id="title_index">Prêt à vous envoler.. ?</div>
<div id="images">
<div><a href="https://www.google.fr/flights/#search;f=BVA,CDG,ORY;t=SFO;q=billets+d%27avion+san+francisco;d=2014-12-23;r=2014-12-27" class="sf">SAN FRANCISCO</a></div>
<div><a href="https://www.youtube.com/watch?v=foimRx1yo3k" class="tokyo">TOKYO</a></div>
<div><a href="http://fr.wikipedia.org/wiki/Capri" class="capri">CAPRI</a></div>
</div>
</div>

<?php get_footer() ?>