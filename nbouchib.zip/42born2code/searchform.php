<form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<input type="text"; name="s"; placeholder="Oú voulez-vous aller ?"; id="searchbox";/>
	<input type="submit" id="searchsubmit" value="<?php _e("Rechercher"); ?>" />
</form>